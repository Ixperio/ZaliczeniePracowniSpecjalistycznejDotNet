using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ProjektArtykuly.Pages
{
    public class AuthorsModel : PageModel
    {
        public void OnGet()
        {

        }
    }
}
