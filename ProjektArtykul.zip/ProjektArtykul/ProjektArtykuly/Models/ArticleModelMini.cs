﻿namespace ProjektArtykuly.Models
{
    public class ArticleModelMini
    {
        public int id { get; set; }
        public string title { get; set; }
        public string intro { get; set; }
        
    }
}
