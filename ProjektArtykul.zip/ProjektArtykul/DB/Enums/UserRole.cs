﻿namespace DB.Enums
{
   public enum UserRole
   {
        Admin = 1,
        Redaktor = 2,
        User = 3
   }
}
