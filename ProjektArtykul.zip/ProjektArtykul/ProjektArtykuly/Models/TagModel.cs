﻿using DB;

namespace ProjektArtykuly.Models
{
    public class TagModel
    {
        public int id { get; set; }
        public string name { get; set; }
        

    }
}
